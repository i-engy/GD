## Note
See [examples](https://github.ids.ray.com/IDS/pcs-xeta-terraform-aws/tree/development/examples) directory for working examples to reference



Configuration in this directory creates:

- EC2 instance
- EBS
- EFS
- Key pair

## Note about the Key Pair

The key pair is dynamic and specific to the user deploying or implementing the resource. 

```hcl

resource "aws_key_pair" "ec2_key" {
  key_name   = var.keypair_name
  public_key = file("~/.ssh/id_rsa.pub")
}
```

The "public_key" is the public key in the user's ~/.ssh/id_rsa.pub with the pem file been "id_rsa".
If this doesn't exist, please generate an rsa keypair id_rsa & id_rsa.pub
The generated or existing private key will be used to "ssh" into the remote server as follow;

```bash
ssh -i "id_rsa" [server_private_ip]
```

## List of available EC2 types

- t3.small 
- t3.medium 
- t3.large 
- t3.xlarge 
- t3.2xlarge 
- GP / General Purpose

## List of Subnets and Availability zone

| Subnet         |  AZ        |
|----------------|------------|
| Priv-1-subnet |  us-gov-east-1a |
| Priv-2-subnet  | us-gov-east-1b |
| Priv-3-subnet  | us-gov-east-1C |
| Priv-4-subnet  | us-gov-east-1a |


## Usage

To run this you need to execute:

```bash
$ terraform init
$ terraform plan
$ terraform apply
```

### Outputs
| Output         |  Description                       |
|----------------|------------------------------------|
| Instance state | The current state of the instance  |
| Private IP  | The private ip of the instance  |
